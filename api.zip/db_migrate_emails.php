<?php
require_once __DIR__ . '/api/config/db.php';

try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `email_templates` (
          `id` varchar(50) NOT NULL,
          `companyId` varchar(50) NOT NULL,
          `key` varchar(50) NOT NULL,
          `name` varchar(100) NOT NULL,
          `subject` varchar(255) NOT NULL,
          `bodyHtml` text NOT NULL,
          `createdAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
          `updatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`id`),
          UNIQUE KEY `idx_comp_key` (`companyId`,`key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    echo "Table 'email_templates' created or already exists.\n";

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `notification_settings` (
          `id` varchar(50) NOT NULL,
          `userId` varchar(50) NOT NULL,
          `emailOnEvalCompleted` tinyint(1) DEFAULT 1,
          `dailySummary` tinyint(1) DEFAULT 0,
          `createdAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
          `updatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`id`),
          UNIQUE KEY `idx_user` (`userId`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");
    echo "Table 'notification_settings' created or already exists.\n";
    
    // Check if the global template exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM email_templates WHERE companyId = 'global' AND `key` = 'invitation_eval'");
    $stmt->execute();
    if ($stmt->fetchColumn() == 0) {
        $globalId = 'tpl_' . uniqid();
        $globalSubj = "Fuiste invitado a una evaluación en [{{NOMBRE_EMPRESA}}]";
        $globalBody = "<p>Hola {{NOMBRE_POSTULANTE}}, has sido invitado a completar la evaluación: <strong>{{NOMBRE_EVALUACION}}</strong>.</p><p><br></p><p>Haz clic en el siguiente enlace para comenzar:</p><p><br></p><p><a href=\"{{LINK_EVALUACION}}\" class=\"btn\">Comenzar evaluación</a></p><p><strong>Usuario:</strong> {{EMAIL_POSTULANTE}}</p><p><strong>Contraseña:</strong> {{PASSWORD_POSTULANTE}}</p>";
        
        $insert = $pdo->prepare("INSERT INTO email_templates (id, companyId, `key`, name, subject, bodyHtml) VALUES (?, 'global', 'invitation_eval', 'Plantilla Global Invitación', ?, ?)");
        $insert->execute([$globalId, $globalSubj, $globalBody]);
        echo "Global template created.\n";
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
