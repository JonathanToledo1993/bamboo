import os
import glob
import re

target_dir = r"c:\Users\USUARIO\Documents\bamboo\public"

brand_regex = re.compile(r'\bKokoro\b')
brand_emp_regex = re.compile(r'Kokoro Empresas')
logo_regex = re.compile(r'<div[^>]*>[\s\n]*K[\s\n]*</div>', re.IGNORECASE)

replacement_logo = '<i class="ph-fill ph-panda text-3xl"></i>'

changed_files = 0

for root, dirs, files in os.walk(target_dir):
    for file in files:
        if file.endswith(".html") or file.endswith(".js"):
            filepath = os.path.join(root, file)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                new_content = brand_emp_regex.sub('Psycopanda Empresas', content)
                new_content = brand_regex.sub('Psycopanda', new_content)
                new_content = logo_regex.sub(replacement_logo, new_content)
                
                if new_content != content:
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(new_content)
                    changed_files += 1
            except Exception as e:
                print(f"Error processing {filepath}: {e}")

print(f"Update complete. Files changed: {changed_files}")
