<?php
$target_dir = __DIR__ . '/public';

$brand_regex = '/\bKokoro\b/';
$brand_emp_regex = '/Kokoro Empresas/';
$logo_regex = '/<div[^>]*>[\s\n]*K[\s\n]*<\/div>/i';
$replacement_logo = '<i class="ph-fill ph-panda text-3xl"></i>';

$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($target_dir));
$changed_files = 0;

foreach ($iterator as $file) {
    if ($file->isFile() && in_array($file->getExtension(), ['html', 'js'])) {
        $filepath = $file->getPathname();
        $content = file_get_contents($filepath);
        if ($content === false) continue;
        
        $new_content = preg_replace($brand_emp_regex, 'Psycopanda Empresas', $content);
        $new_content = preg_replace($brand_regex, 'Psycopanda', $new_content);
        $new_content = preg_replace($logo_regex, $replacement_logo, $new_content);
        
        if ($new_content !== $content) {
            file_put_contents($filepath, $new_content);
            $changed_files++;
        }
    }
}
echo "Update complete. Files changed: $changed_files\n";
?>
